"use client";

import { Menu } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { SidebarNav } from "@/components/app/chrome/site-sidebar";
import { BottomSheet } from "@/components/motion/bottom-sheet";
import { Button } from "@/components/motion/button";
import { PlatformSwitch } from "@/components/app/docs/native/platform-switch";
import { hasPlatformSwitch, hasSiteSidebar, isNativePath, NATIVE_PATH } from "@/lib/component-paths";
import { cn } from "@/lib/utils";

/** Mobile nav: a header hamburger that opens the sidebar list in beUI's own bottom sheet. */
export function MobileNav() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const sidebarPage = hasSiteSidebar(pathname);

  // Covers navigation that doesn't go through a sheet link (back/forward).
  // biome-ignore lint/correctness/useExhaustiveDependencies: pathname is the trigger — close the sheet on any route change.
  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!open) return;
    const desktop = window.matchMedia(sidebarPage ? "(min-width: 768px)" : "(min-width: 1280px)");
    const closeOnDesktop = () => {
      if (desktop.matches) setOpen(false);
    };
    closeOnDesktop();
    desktop.addEventListener("change", closeOnDesktop);
    return () => desktop.removeEventListener("change", closeOnDesktop);
  }, [open, sidebarPage]);

  return (
    <div className={sidebarPage ? "md:hidden" : "xl:hidden"}>
      <Button
        variant="ghost"
        size="icon"
        className="rounded-full"
        onClick={() => setOpen(true)}
        aria-label="Open navigation"
        aria-haspopup="dialog"
        aria-expanded={open}
      >
        <Menu className="h-5 w-5" />
      </Button>
      <BottomSheet
        open={open}
        onOpenChange={setOpen}
        title="Menu"
        snapPoints={[0.85]}
      >
        <div className="flex flex-col gap-5 pt-2">
          {/* The list below follows the platform, so pick it here too. */}
          {hasPlatformSwitch(pathname) ? <PlatformSwitch layout="block" /> : null}
          <nav className="flex flex-wrap gap-1">
            <Link
              href="/components/motion"
              onClick={() => setOpen(false)}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm transition-colors",
                pathname.startsWith("/components/motion")
                  ? "text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              Components
            </Link>
            <Link
              href="/components/blocks"
              onClick={() => setOpen(false)}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm transition-colors",
                pathname.startsWith("/components/blocks")
                  ? "text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              Blocks
            </Link>
            <Link
              href="/components/agents"
              onClick={() => setOpen(false)}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm transition-colors",
                pathname.startsWith("/components/agents")
                  ? "text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              Agents
            </Link>
            <Link
              href="/charts"
              onClick={() => setOpen(false)}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm transition-colors",
                pathname.startsWith("/charts")
                  ? "text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              Charts
            </Link>
            <Link
              href={NATIVE_PATH}
              onClick={() => setOpen(false)}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm transition-colors",
                isNativePath(pathname)
                  ? "text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              React Native
            </Link>
            <Link
              href="/playground"
              onClick={() => setOpen(false)}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm transition-colors",
                pathname.startsWith("/playground")
                  ? "text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              Playground
            </Link>
            <Link
              href="/sponsors"
              onClick={() => setOpen(false)}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm transition-colors",
                pathname.startsWith("/sponsors")
                  ? "text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              Sponsors
            </Link>
          </nav>
          <SidebarNav onNavigate={() => setOpen(false)} />
        </div>
      </BottomSheet>
    </div>
  );
}
