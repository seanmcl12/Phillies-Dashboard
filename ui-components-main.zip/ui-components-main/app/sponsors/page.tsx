import type { LucideIcon } from "lucide-react";
import { SiteFooter } from "@/components/app/chrome/site-footer";
import { ArrowRight, ArrowUpRight, Check, CircleCheck, Gem, Medal, Trophy } from "lucide-react";
import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import type { ReactNode } from "react";
import { CopyButton } from "@/components/app/docs/copy-button";
import { PressLink } from "@/components/app/press-link";
import {
  OpenSponsorSlot,
  type OpenSponsorSlotSize,
} from "@/components/app/sponsors/open-sponsor-slot";
import { SponsorPlanBeam } from "@/components/app/sponsors/sponsor-plan-beam";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Sponsors",
  description:
    "Support beUI's development with monthly sponsor stages through Dodo Payments, GitHub Sponsors, or crypto.",
  alternates: { canonical: "/sponsors" },
  openGraph: {
    title: "Sponsors · beUI",
    description:
      "Support beUI's development with monthly sponsor stages through Dodo Payments, GitHub Sponsors, or crypto.",
    url: "/sponsors",
    type: "website",
    siteName: "beUI",
    images: ["/api/og"],
  },
  twitter: {
    card: "summary_large_image",
    title: "Sponsors · beUI",
    images: ["/api/og"],
  },
};

const GITHUB_SPONSORS_URL = "https://github.com/sponsors/starc007";
const CONTACT_URL = "mailto:hello@beui.dev?subject=beUI%20sponsorship";

const PLAN_STYLES = {
  diamond: {
    card: "border-border bg-card shadow-[0_24px_80px_-48px_rgba(255,255,255,0.75)]",
    icon: "border border-border bg-muted text-foreground",
    Icon: Gem,
    chip: "border-accent/30 bg-accent/10",
    // On phones a filled card takes the full row and open slots pair up.
    grid: "grid-cols-2 md:grid-cols-3",
    filled: "col-span-2 md:col-span-1",
    slot: "lg",
  },
  platinum: {
    card: "border-border bg-card",
    icon: "border border-border bg-muted text-foreground",
    Icon: Trophy,
    chip: "border-border bg-muted",
    grid: "grid-cols-2",
    filled: "",
    slot: "sm",
  },
  silver: {
    card: "border-border bg-card",
    icon: "border border-border bg-muted text-foreground",
    Icon: Medal,
    chip: "border-border bg-muted",
    grid: "grid-cols-2",
    filled: "",
    slot: "sm",
  },
} satisfies Record<
  string,
  {
    card: string;
    icon: string;
    Icon: LucideIcon;
    chip: string;
    grid: string;
    filled: string;
    slot: OpenSponsorSlotSize;
  }
>;

type SponsorTone = keyof typeof PLAN_STYLES;

type DiamondSponsor = {
  name: string;
  tagline: string;
  domain: string;
  /** Icon basename in /public/sponsors, with -light and -dark variants. */
  icon: string;
};

const DIAMOND_SPONSORS: DiamondSponsor[] = [
  {
    name: "Tracwell",
    tagline: "Turn visitor insights into growth",
    domain: "tracwell.app",
    icon: "tracwell-icon",
  },
  {
    name: "Illos",
    tagline: "Animated illustrations for product sites",
    domain: "illos.dev",
    icon: "illos-icon",
  },
];

function DiamondSponsorCard({ name, tagline, domain, icon }: DiamondSponsor) {
  return (
    <Link
      href={`https://${domain}/?utm_source=beui&utm_medium=referral&utm_campaign=sponsorship&utm_content=diamond_sponsor`}
      target="_blank"
      rel="noreferrer noopener"
      className="block h-full min-w-0 rounded-3xl border border-border bg-background p-2 transition-colors hover:border-border-strong focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ring"
    >
      <div className="flex min-h-40 items-center justify-center gap-3 rounded-2xl border border-border bg-linear-to-t from-accent/10 to-card px-4 py-6">
        <Image
          src={`/sponsors/${icon}-light.svg`}
          alt=""
          width={56}
          height={56}
          className="size-14 shrink-0 dark:hidden"
        />
        <Image
          src={`/sponsors/${icon}-dark.svg`}
          alt=""
          width={56}
          height={56}
          className="hidden size-14 shrink-0 dark:block"
        />
        <div>
          <h3 className="font-display text-2xl font-semibold tracking-tight text-foreground">
            {name}
          </h3>
          <p className="mt-1 max-w-44 text-xs leading-relaxed text-muted-foreground">
            {tagline}
          </p>
        </div>
      </div>
      <div className="flex items-center justify-between gap-4 px-3 py-4">
        <span className="text-sm font-medium text-foreground">{domain}</span>
        <ArrowRight aria-hidden="true" className="size-5 shrink-0 text-muted-foreground" />
      </div>
    </Link>
  );
}

// Filled slots per tier. Adding a sponsor here closes one open slot.
const CURRENT_SPONSORS: Record<SponsorTone, { id: string; card: ReactNode }[]> = {
  diamond: DIAMOND_SPONSORS.map((sponsor) => ({
    id: sponsor.domain,
    card: <DiamondSponsorCard {...sponsor} />,
  })),
  platinum: [],
  silver: [],
};

function planTargetId(tone: SponsorTone) {
  return `sponsor-plan-${tone}`;
}

function openSlotCount(tone: SponsorTone, slots: number) {
  return Math.max(0, slots - CURRENT_SPONSORS[tone].length);
}

function SponsorTier({
  name,
  price,
  tone,
  slots,
}: {
  name: string;
  price: string;
  tone: SponsorTone;
  slots: number;
}) {
  const styles = PLAN_STYLES[tone];
  const Icon = styles.Icon;
  const sponsors = CURRENT_SPONSORS[tone];
  const open = openSlotCount(tone, slots);
  const headingId = `${tone}-sponsors`;

  return (
    <section aria-labelledby={headingId} className="min-w-0">
      <div className="flex flex-wrap items-center gap-3">
        <h2
          id={headingId}
          className={cn(
            "inline-flex items-center gap-2 rounded-lg border px-3 py-2 font-mono text-sm font-medium text-foreground",
            styles.chip,
          )}
        >
          <Icon aria-hidden="true" className="size-4" />
          {name}
        </h2>
        <p className="text-xs text-muted-foreground">
          {open > 0 ? `${open} of ${slots} open` : "All slots taken"}
        </p>
      </div>
      <div className={cn("mt-4 grid gap-4", styles.grid)}>
        {sponsors.map((sponsor) => (
          <div key={sponsor.id} className={styles.filled}>
            {sponsor.card}
          </div>
        ))}
        {Array.from({ length: open }, (_, index) => (
          <OpenSponsorSlot
            // Open slots are interchangeable placeholders with no identity.
            // biome-ignore lint/suspicious/noArrayIndexKey: see above
            key={index}
            tier={name}
            price={price}
            targetId={planTargetId(tone)}
            size={styles.slot}
          />
        ))}
      </div>
    </section>
  );
}

// Updated by hand from the Tracwell dashboard. Values are rounded down and
// shown as "at least", so the page never overstates traffic.
const TRAFFIC_UPDATED_AT = "Oct 23, 2026";
const TRAFFIC_STATS = [
  { period: "Last 30 days", visitors: 54_000, pageViews: 800_000 },
  { period: "Last 90 days", visitors: 175_000, pageViews: 2_400_000 },
];

const compactNumber = new Intl.NumberFormat("en-US", {
  notation: "compact",
  maximumFractionDigits: 1,
});

function TrafficStat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-border bg-background px-4 py-4">
      <dt className="text-sm text-muted-foreground">{label}</dt>
      <dd
        className="mt-1 text-3xl font-semibold tabular-nums tracking-tight text-foreground"
        title={`More than ${value.toLocaleString("en-US")}`}
      >
        {compactNumber.format(value)}+
      </dd>
    </div>
  );
}

function truncateAddress(address: string) {
  return address.length > 14
    ? `${address.slice(0, 6)}...${address.slice(-6)}`
    : address;
}

function AddressRow({ label, address }: { label: string; address: string }) {
  return (
    <div className="grid grid-cols-[5rem_minmax(0,1fr)_auto] items-center gap-4 rounded-xl border border-border px-4 py-3">
      <p className="whitespace-nowrap text-sm font-medium text-muted-foreground">
        {label}
      </p>
      <p className="min-w-0 truncate whitespace-nowrap font-mono text-sm text-foreground">
        {truncateAddress(address)}
      </p>
      <CopyButton text={address} eventName="copy_sponsor_address" eventLabel={label} />
    </div>
  );
}

function SponsorPlanCard({
  name,
  price,
  description,
  benefits,
  paymentUrl,
  featured = false,
  tone,
  slots,
}: {
  name: string;
  price: string;
  description: string;
  benefits: string[];
  paymentUrl?: string;
  featured?: boolean;
  tone: SponsorTone;
  slots: number;
}) {
  const styles = PLAN_STYLES[tone];
  const Icon = styles.Icon;
  const href = paymentUrl || CONTACT_URL;
  const open = openSlotCount(tone, slots);

  return (
    <SponsorPlanBeam enabled={featured} className="h-full">
      <div
        id={planTargetId(tone)}
        tabIndex={-1}
        className={cn(
          "relative flex h-full scroll-mt-24 flex-col overflow-hidden rounded-3xl border p-5 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ring",
          styles.card,
        )}
      >
        {featured ? (
          <span className="absolute right-4 top-4 rounded-full border border-white/10 bg-foreground px-2.5 py-1 text-[0.68rem] font-semibold uppercase tracking-wider text-background">
            Highest impact
          </span>
        ) : null}
        <div className="flex items-start justify-between gap-4 pr-24">
          <div
            className={cn(
              "flex h-11 w-11 items-center justify-center rounded-2xl",
              styles.icon,
          )}
        >
          <Icon className="h-4 w-4" />
        </div>
        </div>
        <div className="mt-6">
          <h2 className="text-xl font-semibold tracking-tight text-foreground">
            {name}
          </h2>
          <p className="mt-2 min-h-12 text-sm leading-relaxed text-muted-foreground">
            {description}
          </p>
        </div>
        <div className="mt-6 flex items-baseline gap-2 border-t border-border pt-5">
          <span className="text-4xl font-semibold tracking-tight text-foreground">
            {price}
          </span>
          <span className="text-sm text-muted-foreground">/mo</span>
          <span className="ml-auto text-xs text-muted-foreground">
            {open > 0 ? `${open} of ${slots} open` : "Full"}
          </span>
        </div>
        <ul className="mb-6 mt-6 min-h-32 space-y-3 text-sm text-foreground">
          {benefits.map((benefit) => (
            <li key={benefit} className="flex gap-2.5">
              <Check className="mt-0.5 h-4 w-4 shrink-0 text-foreground" />
              <span>{benefit}</span>
            </li>
          ))}
        </ul>
        <PressLink
          href={href}
          target={paymentUrl ? "_blank" : undefined}
          rel={paymentUrl ? "noreferrer noopener" : undefined}
          className={cn(
            "group mt-auto inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition-colors",
            featured
              ? "bg-primary text-primary-foreground hover:bg-primary/90"
              : "border border-border bg-background text-foreground hover:border-border-strong",
          )}
        >
          {paymentUrl ? `Sponsor as ${name}` : "Request payment link"}
          <ArrowUpRight className="h-4 w-4 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
        </PressLink>
      </div>
    </SponsorPlanBeam>
  );
}

export default async function SponsorsPage({
  searchParams,
}: {
  searchParams?: Promise<{ success?: string }>;
}) {
  const resolvedSearchParams = await searchParams;
  const checkoutSucceeded = resolvedSearchParams?.success === "true";
  const evmAddress = process.env.SPONSOR_EVM_ADDRESS;
  const solAddress = process.env.SPONSOR_SOL_ADDRESS;
  const sponsorPlans = [
    {
      name: "Diamond",
      price: "$199",
      description:
        "Maximum visibility for teams that want their logo in the highest-signal sponsor slot.",
      benefits: [
        "Logo on the home page, right below the hero",
        "Largest logo placement on the sponsors page",
        "Largest logo placement in the docs sidebar",
        "Largest logo placement in the README",
        "Shoutout on X after sponsorship",
        "Priority feedback channel for requests",
      ],
      paymentUrl:
        process.env.DODO_SPONSOR_DIAMOND_SUBSCRIPTION_URL ??
        process.env.DODO_SPONSOR_DIAMOND_URL,
      featured: true,
      tone: "diamond" as const,
      slots: 3,
    },
    {
      name: "Platinum",
      price: "$99",
      description:
        "Prominent placement for product teams supporting polished open-source UI.",
      benefits: [
        "Larger logo placement on the sponsors page",
        "Large logo placement in the docs sidebar",
        "Larger logo placement in the README",
        "Shoutout on X after sponsorship",
      ],
      paymentUrl:
        process.env.DODO_SPONSOR_PLATINUM_SUBSCRIPTION_URL ??
        process.env.DODO_SPONSOR_PLATINUM_URL,
      tone: "platinum" as const,
      slots: 2,
    },
    {
      name: "Silver",
      price: "$49",
      description:
        "A simple way to support ongoing component work and be listed publicly.",
      benefits: [
        "Logo on the sponsors page",
        "Logo placement in the docs sidebar",
        "Logo in the README",
        "Public sponsor listing",
      ],
      paymentUrl:
        process.env.DODO_SPONSOR_SILVER_SUBSCRIPTION_URL ??
        process.env.DODO_SPONSOR_SILVER_URL,
      tone: "silver" as const,
      slots: 2,
    },
  ];

  return (
    <>
      <div className="mx-auto max-w-7xl px-4 py-16">
        {checkoutSucceeded ? (
          <div className="mx-auto mb-8 flex max-w-xl gap-3 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-4">
            <CircleCheck className="h-5 w-5 shrink-0 text-emerald-600 dark:text-emerald-400" />
            <div>
              <p className="text-sm font-semibold text-emerald-950 dark:text-emerald-100">
                Sponsorship checkout complete
              </p>
              <p className="mt-1 text-sm leading-relaxed text-emerald-900/75 dark:text-emerald-100/75">
                Thanks for sponsoring beUI. I’ll follow up for logo assets and
                placement details.
              </p>
            </div>
          </div>
        ) : null}
        <div className="max-w-2xl">
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Sponsors
          </p>
          <h1 className="mt-2 text-4xl font-semibold tracking-tight text-foreground">
            Support beUI
          </h1>
          <p className="mt-3 text-muted-foreground">
            beUI is free and open source. Sponsor a monthly stage to reach
            developers actively browsing motion components, blocks, and registry
            installs.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <PressLink
              href={GITHUB_SPONSORS_URL}
              target="_blank"
              rel="noreferrer noopener"
              className="group inline-flex items-center justify-center gap-2 rounded-full border border-border bg-background px-5 py-3 text-sm font-semibold text-foreground transition-colors hover:border-border-strong"
            >
              Sponsor on GitHub
              <ArrowUpRight className="h-4 w-4 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </PressLink>
          </div>
        </div>

        <section aria-labelledby="traffic-stats" className="mt-12">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <h2
              id="traffic-stats"
              className="text-xs font-semibold uppercase tracking-wider text-muted-foreground"
            >
              Audience
            </h2>
            <p className="text-xs text-muted-foreground">
              Analytics by Tracwell, updated {TRAFFIC_UPDATED_AT}
            </p>
          </div>
          <div className="mt-3 grid gap-4 md:grid-cols-2">
            {TRAFFIC_STATS.map((stat) => (
              <div
                key={stat.period}
                className="rounded-3xl border border-border bg-card p-2"
              >
                <h3 className="px-3 pb-2 pt-2 text-sm font-medium text-foreground">
                  {stat.period}
                </h3>
                <dl className="grid grid-cols-2 gap-2">
                  <TrafficStat label="Visitors" value={stat.visitors} />
                  <TrafficStat label="Page views" value={stat.pageViews} />
                </dl>
              </div>
            ))}
          </div>
        </section>

        <div className="mt-12 space-y-10">
          {sponsorPlans
            .filter((plan) => plan.tone === "diamond")
            .map((plan) => (
              <SponsorTier key={plan.name} {...plan} />
            ))}
          {/* Platinum and Silver share a row; the 3:2 split keeps each
              Platinum slot wider than a Silver one. */}
          <div className="grid gap-10 md:grid-cols-[3fr_2fr] md:gap-4">
            {sponsorPlans
              .filter((plan) => plan.tone !== "diamond")
              .map((plan) => (
                <SponsorTier key={plan.name} {...plan} />
              ))}
          </div>
        </div>

        <section
          id="sponsor-plans"
          aria-label="Sponsor plans"
          className="mt-12 scroll-mt-24"
        >
          <div className="grid gap-4 md:grid-cols-3">
            {sponsorPlans.map((plan) => (
              <SponsorPlanCard key={plan.name} {...plan} />
            ))}
          </div>
        </section>

        {evmAddress || solAddress ? (
          <div className="mt-14">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Crypto
            </p>
            <div className="mt-3 grid gap-3 md:grid-cols-2">
              {evmAddress ? <AddressRow label="EVM" address={evmAddress} /> : null}
              {solAddress ? (
                <AddressRow label="Solana" address={solAddress} />
              ) : null}
            </div>
          </div>
        ) : null}
      </div>
      <SiteFooter />
    </>
  );
}
